"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { FormError, runFormAction, type FormState } from "@/lib/form-state";
import { getCreatorAccount } from "@/lib/creator/access";
import { isUuid } from "@/lib/validation";

export async function submitCreatorProductOpportunityProposal(_state: FormState, formData: FormData) {
  return runFormAction(async () => {
    const opportunityId = String(formData.get("opportunity_id") ?? "");
    const amount = Number(formData.get("amount"));
    const offerDetails = String(formData.get("offer_details") ?? "").trim();
    const shareEmail = formData.get("share_email") === "on";
    const sharePhone = formData.get("share_phone") === "on";
    const contactPhone = String(formData.get("contact_phone") ?? "").trim();
    if (!isUuid(opportunityId) || !Number.isFinite(amount) || amount <= 0 || amount > 1_000_000
      || Math.round(amount * 100) / 100 !== amount) {
      throw new FormError("Enter a valid offer amount.");
    }
    if (offerDetails.length < 30 || offerDetails.length > 2000) {
      throw new FormError("Describe what you will deliver in 30 to 2,000 characters.");
    }
    if (!shareEmail && !sharePhone) throw new FormError("Choose at least one contact method to share if your offer is selected.");
    if (sharePhone && !/^\+?[0-9() -]{7,32}$/.test(contactPhone)) {
      throw new FormError("Enter a valid phone number to share with the seller.");
    }

    const { supabase } = await getCreatorAccount();
    const { error } = await supabase.rpc("creator_submit_product_opportunity_proposal", {
      p_opportunity_id: opportunityId,
      p_amount: amount,
      p_offer_details: offerDetails,
      p_share_email: shareEmail,
      p_share_phone: sharePhone,
      p_contact_phone: sharePhone ? contactPhone : null,
    });
    if (error?.code === "22023" || error?.code === "55000" || error?.code === "42501") {
      throw new FormError(error.message);
    }
    if (error) throw new Error(error.message);
    revalidatePath("/creator/opportunities");
    revalidatePath(`/creator/opportunities/${opportunityId}`);
    redirect(`/creator/opportunities/${opportunityId}?submitted=1`);
  });
}

export async function withdrawCreatorProductOpportunityProposal(formData: FormData) {
  const proposalId = String(formData.get("proposal_id") ?? "");
  if (!isUuid(proposalId)) throw new FormError("Invalid creator offer.");
  const { supabase } = await getCreatorAccount();
  const { data: proposal, error: proposalError } = await supabase.from("creator_product_opportunity_proposals")
    .select("opportunity_id").eq("id", proposalId).maybeSingle();
  if (proposalError) throw new Error(proposalError.message);
  if (!proposal) throw new FormError("Creator offer not found.");
  const { error } = await supabase.rpc("creator_withdraw_product_opportunity_proposal", { p_proposal_id: proposalId });
  if (error?.code === "55000" || error?.code === "42501") throw new FormError(error.message);
  if (error) throw new Error(error.message);
  revalidatePath("/creator/opportunities");
  revalidatePath(`/creator/opportunities/${proposal.opportunity_id}`);
  redirect(`/creator/opportunities/${proposal.opportunity_id}?withdrawn=1`);
}

function throwKnownError(error: { code?: string; message: string } | null) {
  if (error?.code === "22023" || error?.code === "55000" || error?.code === "42501" || error?.code === "23505") {
    throw new FormError(error.message);
  }
  if (error) throw new Error(error.message);
}

export async function markCreatorProductOpportunityDelivered(_state: FormState, formData: FormData) {
  return runFormAction(async () => {
    const opportunityId = String(formData.get("opportunity_id") ?? "");
    const deliveryUrl = String(formData.get("delivery_url") ?? "").trim();
    const deliveryNote = String(formData.get("delivery_note") ?? "").trim();
    if (!isUuid(opportunityId)) throw new FormError("Invalid creator promotion.");
    if (!/^https:\/\/\S+$/.test(deliveryUrl) || deliveryUrl.length > 500) {
      throw new FormError("Add a secure https link to the published content.");
    }
    if (deliveryNote.length > 1000) throw new FormError("Keep the delivery note under 1,000 characters.");
    const { supabase } = await getCreatorAccount();
    const { error } = await supabase.rpc("creator_mark_product_opportunity_delivered", {
      p_opportunity_id: opportunityId,
      p_delivery_url: deliveryUrl,
      p_delivery_note: deliveryNote || null,
    });
    throwKnownError(error);
    revalidatePath("/creator/opportunities");
    revalidatePath(`/creator/opportunities/${opportunityId}`);
    redirect(`/creator/opportunities/${opportunityId}?delivered=1`);
  });
}

export async function rateSellerForProductOpportunity(_state: FormState, formData: FormData) {
  return runFormAction(async () => {
    const opportunityId = String(formData.get("opportunity_id") ?? "");
    const rating = Number(formData.get("rating"));
    const comment = String(formData.get("comment") ?? "").trim();
    if (!isUuid(opportunityId)) throw new FormError("Invalid creator promotion.");
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new FormError("Choose a rating from 1 to 5.");
    if (comment.length > 500) throw new FormError("Keep your comment under 500 characters.");
    const { supabase } = await getCreatorAccount();
    const { error } = await supabase.rpc("submit_product_opportunity_review", {
      p_opportunity_id: opportunityId,
      p_rating: rating,
      p_comment: comment || null,
    });
    throwKnownError(error);
    revalidatePath(`/creator/opportunities/${opportunityId}`);
    redirect(`/creator/opportunities/${opportunityId}?rated=1`);
  });
}