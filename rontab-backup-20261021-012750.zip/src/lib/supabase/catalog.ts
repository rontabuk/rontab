import "server-only";

import { cache } from "react";
import { cacheLife, cacheTag } from "next/cache";
import type { Product, ProductCategory } from "@/data/products";
import { getVisibleCategoryRows } from "@/lib/categories";
import type { Database } from "@/lib/supabase/database.types";
import { createSupabasePublicClient } from "@/lib/supabase/server";
import { createProductMediaUrls } from "@/lib/supabase/storage";

type ProductImageRow = Database["public"]["Tables"]["product_images"]["Row"];

// Products lead with their Reel when one exists, otherwise with their first photo.
export function pickLeadMedia<T extends Pick<ProductImageRow, "product_id" | "media_type">>(mediaRows: readonly T[]) {
  const leadMedia = new Map<string, T>();
  for (const media of mediaRows) {
    if (!leadMedia.has(media.product_id) || media.media_type === "video") leadMedia.set(media.product_id, media);
  }
  return leadMedia;
}

export type TopVideoAd = { id: string; title: string; mediaUrl: string; mediaType: "video" | "image"; displaySeconds: number; targetUrl: string | null };

export async function getTopVideoAds(): Promise<TopVideoAd[]> {
  const supabase = createSupabasePublicClient();
  const { data, error } = await supabase
    .from("top_video_ads")
    .select("id,title,storage_path,media_type,display_seconds,target_url")
    .eq("is_active", true)
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: false });

  // The banner is optional, so a failed read must not take the catalogue down.
  if (error) {
    console.error("Top video ads could not be loaded:", error.message);
    return [];
  }

  return data.map((ad) => ({
    id: ad.id,
    title: ad.title,
    mediaUrl: supabase.storage.from("top-video-ads").getPublicUrl(ad.storage_path).data.publicUrl,
    mediaType: ad.media_type,
    displaySeconds: ad.display_seconds,
    targetUrl: ad.target_url,
  }));
}

type CatalogFilter = {
  slug?: string;
  excludeSlug?: string;
  categorySlug?: string;
  excludeCategory?: boolean;
  limit?: number;
};

async function loadPublicCatalog(filter: CatalogFilter = {}): Promise<{
  categories: ProductCategory[];
  products: Product[];
}> {
  "use cache";
  cacheLife({ stale: 30, revalidate: 30, expire: 60 });
  cacheTag("public-catalog");

  const supabase = createSupabasePublicClient();
  const categoriesQuery = supabase
    .from("categories")
    .select("id,slug,name,parent_id")
    .eq("is_active", true)
    .order("sort_order", { ascending: true });
  let productsQuery = supabase
    .from("products")
    .select("id,slug,name,description,audio_script,price,view_count,click_count,featured_until,new_until,category_id,seller_profile_id")
    .eq("status", "approved")
    .order("created_at", { ascending: false });

  if (filter.slug) productsQuery = productsQuery.eq("slug", filter.slug);
  if (filter.excludeSlug) productsQuery = productsQuery.neq("slug", filter.excludeSlug);
  if (filter.limit !== undefined) productsQuery = productsQuery.limit(filter.limit);

  const categoriesPromise = Promise.resolve(categoriesQuery);
  if (filter.categorySlug) {
    const categories = await categoriesPromise;
    if (categories.error) throw categories.error;
    const category = getVisibleCategoryRows(categories.data).find((item) => item.slug === filter.categorySlug);
    if (category) {
      productsQuery = filter.excludeCategory
        ? productsQuery.neq("category_id", category.id)
        : productsQuery.eq("category_id", category.id);
    } else if (!filter.excludeCategory) {
      return { categories: [], products: [] };
    }
  }

  const [categoriesResult, productsResult] = await Promise.all([categoriesPromise, productsQuery]);

  if (categoriesResult.error) throw categoriesResult.error;
  if (productsResult.error) throw productsResult.error;

  const visibleCategories = getVisibleCategoryRows(categoriesResult.data);
  const categoryById = new Map(visibleCategories.map((category) => [category.id, category]));
  const productRows = productsResult.data.filter((product) => categoryById.has(product.category_id));
  const sellerIds = [...new Set(productRows.map((product) => product.seller_profile_id))];
  const productIds = productRows.map((product) => product.id);

  const [sellersResult, mediaResult, sellerPhonesResult, sellerBadgesResult] = await Promise.all([
    sellerIds.length
      ? supabase.from("seller_profiles").select("id,slug,shop_name,shop_url,logo_url").in("id", sellerIds)
      : Promise.resolve({ data: [], error: null }),
    productIds.length
      ? supabase
          .from("product_images")
          .select("product_id,storage_path,media_type,alt_text")
          .in("product_id", productIds)
          .order("sort_order", { ascending: true })
      : Promise.resolve({ data: [], error: null }),
      sellerIds.length
        ? supabase.rpc("get_public_seller_contact_phones", { p_seller_profile_ids: sellerIds })
        : Promise.resolve({ data: [], error: null }),
    sellerIds.length
      ? supabase.rpc("get_public_seller_verification_badges", { p_seller_profile_ids: sellerIds })
      : Promise.resolve({ data: [], error: null }),
  ]);

  if (sellersResult.error) throw sellersResult.error;
  if (mediaResult.error) throw mediaResult.error;
      if (sellerPhonesResult.error) throw sellerPhonesResult.error;
  if (sellerBadgesResult.error) throw sellerBadgesResult.error;

      const sellerPhones = new Map((sellerPhonesResult.data ?? []).map((contact) => [contact.seller_profile_id, contact.phone]));
      const sellerBadges = new Map((sellerBadgesResult.data ?? []).filter((badge) => badge.is_verified).map((badge) => [badge.seller_profile_id, badge.is_blue ? "blue" as const : "grey" as const]));
      const sellers = new Map(sellersResult.data.map((seller) => [seller.id, { ...seller, phone: sellerPhones.get(seller.id) ?? null, badge: sellerBadges.get(seller.id) }]));
  const leadMediaByProduct = pickLeadMedia(mediaResult.data);
  const mediaUrls = await createProductMediaUrls(
    supabase,
    [...leadMediaByProduct.values()].map((media) => media.storage_path),
  );

  return {
    categories: visibleCategories.map((category) => ({
      id: category.slug,
      name: category.name,
      parentId: category.parent_id ? categoryById.get(category.parent_id)?.slug ?? null : null,
    })),
    products: productRows.map((row) => {
      const category = categoryById.get(row.category_id);
      const media = leadMediaByProduct.get(row.id);
      const seller = sellers.get(row.seller_profile_id);

      return {
        id: row.id,
        sellerProfileId: row.seller_profile_id,
        slug: row.slug,
        name: row.name,
        category: category?.slug ?? "home",
        categoryName: category?.name ?? "Home",
        price: row.price,
        viewCount: row.view_count,
        clickCount: row.click_count,
        featuredUntil: row.featured_until,
        newUntil: row.new_until,
        description: row.description,
        audioScript: row.audio_script,
        image: media ? mediaUrls.get(media.storage_path) ?? "" : "",
        imageAlt: media?.alt_text || row.name,
        mediaType: media?.media_type ?? "image",
        maker: seller?.shop_name ?? "Independent maker",
        shopSlug: seller?.slug ?? null,
        shopUrl: seller?.shop_url ?? null,
        shopPhone: seller?.phone ?? null,
        sellerBadge: seller?.badge,
        makerImage: seller?.logo_url?.startsWith("https://") ? seller.logo_url : "",
      };
    }),
  };
}

export const getPublicCatalog = cache(() => loadPublicCatalog());

export const getPublicProduct = cache(async (slug: string) => {
  const { products } = await loadPublicCatalog({ slug, limit: 1 });
  return products[0] ?? null;
});

export const getRelatedPublicProducts = cache(async (slug: string, categorySlug: string) => {
  const { products } = await loadPublicCatalog({ excludeSlug: slug, categorySlug, limit: 8 });
  if (products.length === 8) return products;
  const { products: otherProducts } = await loadPublicCatalog({
    excludeSlug: slug,
    categorySlug,
    excludeCategory: true,
    limit: 8 - products.length,
  });
  return [...products, ...otherProducts];
});
