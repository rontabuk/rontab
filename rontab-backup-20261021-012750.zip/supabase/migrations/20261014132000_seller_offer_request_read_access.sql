grant select on public.seller_offer_request_locations,
	public.seller_offer_request_schedules to authenticated;